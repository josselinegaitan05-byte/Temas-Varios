# Laboratorio: CRUD, Inyección SQL, Sobrecarga, Recursividad y Frecuencias

**Universidad Tecnológica de Panamá** · Facultad de Ingeniería en Sistemas · Campus Víctor Levis Sasso
**Materia:** Herramientas de la Programación Aplicada III (.NET) · **Grupo:** 1IL133
**Instructora:** Ing. Irina Fong · **Módulo IV:** Acceso a base de datos – Aplicaciones en capas
**Fecha de entrega:** ____ de octubre de 2026 · **Estudiante:** ____________________

## Tecnologías y versiones
- SDK de .NET: **.NET 10.0** (`net10.0`) — verificar con `dotnet --version`
- Lenguaje: **C# 14**
- IDE: Visual Studio 2026 (solución `.slnx`)

## Instalación y uso
```bash
git clone <URL-DEL-REPOSITORIO>
cd Lab_Sobrecarga_CRUD
dotnet restore Lab_Sobrecarga.slnx
dotnet build Lab_Sobrecarga.slnx

dotnet run --project Escenario1_CRUD_SQL
dotnet run --project Escenario2_Sobrecarga_Recursividad
dotnet run --project Escenario3_Frecuencias
```
También se puede abrir `Lab_Sobrecarga.slnx` en Visual Studio y ejecutar cada proyecto.

## Escenarios
| # | Proyecto | Contenido |
|---|----------|-----------|
| 1 | `Escenario1_CRUD_SQL` | Construcción de INSERT/UPDATE por cadenas, demostración de inyección SQL y versión parametrizada |
| 2 | `Escenario2_Sobrecarga_Recursividad` | Clase `Calculadora` con métodos sobrecargados y `Factorial` recursivo con caso base |
| 3 | `Escenario3_Frecuencias` | Conteo de frecuencias de un arreglo y de 6000 tiros de dado |

## Proyecto CRUD de apoyo: `ProyectoProductos_CRUD`
Aplicación Windows Forms (.NET Framework 4.7.2) con MySQL que implementa el CRUD completo de la tabla `productos` (nombre, precio, cantidad, imagen).
- Todas las operaciones usan **consultas parametrizadas** (`InsertSeguro`, `UpdateSeguro`, `DeleteSeguro`, y búsqueda con `LIKE @filtro`).
- `Conexion.cs` incluye además `ConstruirInsertInseguro`, `ConstruirUpdateInseguro` y `ConstruirBusquedaInsegura`, solo para contrastar (el formulario no las usa). El Escenario 1 reproduce esa misma lógica en consola con las columnas de esta tabla.
- Pasos: crear la base con `crear_base_datos.sql` en MySQL, ajustar `Uid`/`Pwd` en `Conexion.cs`, abrir `ProyectoProductos.sln` en Visual Studio (restaura NuGet automáticamente) y ejecutar. Requiere Windows.

## Evidencias
Capturas de la ejecución en la carpeta `evidencias/`:

![Escenario 1](evidencias/escenario1.png)
![Escenario 2](evidencias/escenario2.png)
![Escenario 3](evidencias/escenario3.png)

## Conclusiones
- Concatenar texto del usuario dentro de SQL permite que este altere la sentencia; los parámetros (`@campo`) separan código y datos.
- La sobrecarga permite reutilizar un nombre con distintas firmas; el compilador elige según los argumentos.
- Toda función recursiva necesita un caso base y avanzar hacia él para evitar un `StackOverflow`.
- Un diccionario permite contar frecuencias recorriendo los datos una sola vez.

---
*Universidad Tecnológica de Panamá — Herramientas de la Programación Aplicada III (.NET) — Octubre 2026*
